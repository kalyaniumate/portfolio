Kalyani Umate Portfolio

Files:
- index.html: self-contained responsive portfolio website.

How to use:
1. Extract this ZIP file.
2. Open index.html in Chrome, Edge, or Firefox.
3. To publish online, upload index.html to a static hosting service such as Netlify or Vercel.

Notes:
- Agile Trainer Certification and Agile Coach Certification have been removed.
- Replace any placeholder social/project/resume links with your real URLs before publishing.
- The contact form may open an email draft; it does not send messages through a backend.
